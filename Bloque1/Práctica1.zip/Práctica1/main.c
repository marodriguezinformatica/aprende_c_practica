#include <stdio.h>
#include <stdlib.h>
/*Este programa ejemplifica el uso del entorno de desarrollo para escribir
programas en lenguaje C,
mediante una instrucci�n que muestra mensaje de bienvenida por la consola*/
int main()
{
    //Muestra por pantalla el mensaje indicado
    printf("Hola Mundo Lenguaje C\n");
    return 0;
}
